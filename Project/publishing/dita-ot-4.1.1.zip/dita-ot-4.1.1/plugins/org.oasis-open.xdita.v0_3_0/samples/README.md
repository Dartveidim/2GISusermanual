# Cross-format Content with Lightweight DITA (LwDITA draft as of 2018-08-24)


**Experimental LwDITA authoring modes included. Not all topics and elements are functional in actual LwDITA transformations**
