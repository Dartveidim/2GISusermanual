# Lightweight DITA DTDs

The current preliminary XDITA DTDs are stored here.
