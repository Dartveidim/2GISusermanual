# DITA 2.0 Draft Grammar files

This directory contains a draft version the DITA Version 2.0 Relax NG and DTD grammar files. 

This draft is a work in progress.