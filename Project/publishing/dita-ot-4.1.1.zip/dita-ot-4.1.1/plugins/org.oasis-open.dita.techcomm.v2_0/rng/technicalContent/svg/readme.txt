This directory contains the RELAX NG grammar definitions for various versions
of SVG. As of March 2014 the current version of SVG 1.1.

The SVG RELAX NG materials are found here: http://www.w3.org/Graphics/SVG/1.1/rng/

The relaxng.dtd file is used by the SVG 1.1 grammar documents as provided
by the W3C and is included here in order to avoid the need to modify those
files.