DITA-OT LwDITA plug-in contains

- a custom parser for Markdown and HTML to allow using Markdown DITA and HTML DITA, respectively, as a source document format,
- and a transtype to generate Markdown from DITA source.

The Markdown DITA files need to use a subset of Markdown constructs for compatibility with DITA content models.
